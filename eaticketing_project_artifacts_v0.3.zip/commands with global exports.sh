#make sure to have genesis.json, createfiles.py and this
#commands.sh files in the home directory before running this script

#intall geth
sudo add-apt-repository -y ppa:ethereum/ethereum
sudo apt-get update
sudo apt-get install ethereum -y

#set environment variables for ports
node1port=30306
node1rpcport=8551
node1httpport=3336
node2port=$node1port+1
node2rpcport=$node1rpcport+1
node2httpport=$node1httpport+1
node3port=$node1port+2
node3rpcport=$node1rpcport+2
node3httpport=$node1httpport+2

#make environment variables available in all shells
sudo echo node1port=$node1port | sudo tee -a /etc/environment
sudo echo node1rpcport=$node1rpcport | sudo tee -a /etc/environment
sudo echo node1httpport=$node1httpport | sudo tee -a /etc/environment
sudo echo node2port=$node2port | sudo tee -a /etc/environment
sudo echo node2rpcport=$node2rpcport | sudo tee -a /etc/environment
sudo echo node2httpport=$node2httpport | sudo tee -a /etc/environment
sudo echo node3port=$node3port | sudo tee -a /etc/environment
sudo echo node3rpcport=$node3rpcport | sudo tee -a /etc/environment
sudo echo node3httpport=$node3httpport | sudo tee -a /etc/environment

#prepare the directories for creating 3 nodes and 1 bootnode
rm -rf ethereum
mkdir ethereum
cd ethereum
mkdir bnode
mkdir node1
mkdir node2
mkdir node3
echo '12345678' > password.txt
cp ../genesis.json .
cp ../createfiles.py .
geth --password password.txt --datadir node1/data account new > node1.txt
geth --password password.txt --datadir node2/data account new > node2.txt
geth --password password.txt --datadir node3/data account new > node3.txt
python3 createfiles.py
geth init --datadir node1/data ../genesis.json
geth init --datadir node2/data ../genesis.json
geth init --datadir node3/data ../genesis.json
bootnode -genkey bnode/boot.key
bootnode -nodekey bnode/boot.key -addr :30305 --writeaddress --verbosity 7 > enode.txt

# patch the IP address present in the enodetail variable to
# to public IP of the ec2 machine, before running this script
enodehead=enode://
enodetail=@54.166.227.118:0?discport=30305
enodelink=$(cat enode.txt)

#set environment variables for enodelink, chainid, etc
enodelink="$enodehead$enodelink$enodetail"
chainid=$(cat chainid.txt)
node1pubkey=$(cat node11.txt)
node2pubkey=$(cat node22.txt)
node3pubkey=$(cat node33.txt)

#make the available globally
sudo echo enodelink=$enodelink | sudo tee -a /etc/environment
sudo echo chainid=$chainid | sudo tee -a /etc/environment
sudo echo node1pubkey=$node1pubkey | sudo tee -a /etc/environment
sudo echo node2pubkey=$node2pubkey | sudo tee -a /etc/environment
sudo echo node3pubkey=$node3pubkey | sudo tee -a /etc/environment

echo bootnode -nodekey bnode/boot.key -addr :30305 --verbosity 7
echo geth --datadir node1/data --port $node1port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node1httpport --http.corsdomain '*' --http.vhosts "*" --http.api web3,eth,debug,personal,net --unlock $node1pubkey --password password.txt --authrpc.port $node1rpcport --miner.etherbase $node1pubkey --mine --syncmode "full" --verbosity 7 --vmdebug console
echo geth --datadir node2/data --port $node2port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node2httpport --http.corsdomain '*' --http.vhosts "*" --http.api web3,eth,debug,personal,net --unlock $node2pubkey --password password.txt --authrpc.port $node2rpcport --miner.etherbase $node2pubkey --mine --syncmode "full" --verbosity 7 --vmdebug console
echo geth --datadir node3/data --port $node3port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node3httpport --http.corsdomain '*' --http.vhosts "*" --http.api web3,eth,debug,personal,net --unlock $node3pubkey --password password.txt --authrpc.port $node3rpcport --syncmode "full" --verbosity 7 --vmdebug console

rootdir=$(pwd)
basedirname=besu
datadirname=data
node1name=Node-1
node2name=Node-2
node3name=Node-3

node1dir=~/$basedirname/$node1name
node2dir=~/$basedirname/$node2name
node3dir=~/$basedirname/$node3name
node1datadir=$node1dir/$datadirname
node2datadir=$node2dir/$datadirname
node3datadir=$node3dir/$datadirname

node1p2pport=30309
node1httpport=8549
node2p2pport=$((node1p2pport+1))
node2httpport=$((node1httpport+1))
node3p2pport=$((node1p2pport+2))
node3httpport=$((node1httpport+2))

networkid=1338
tesseradirname=Tessera

PATH=$PATH:/besu-23.10.3/bin
PATH=$PATH:/tessera-23.4.0/bin

rm -rf $basedirname
mkdir $basedirname
mkdir $basedirname/$node1name
mkdir $basedirname/$node2name
mkdir $basedirname/$node3name
mkdir $basedirname/$node1name/$datadirname
mkdir $basedirname/$node2name/$datadirname
mkdir $basedirname/$node3name/$datadirname
mkdir $basedirname/$node1name/$tesseradirname
mkdir $basedirname/$node2name/$tesseradirname

cd $node1dir
besu --data-path=$datadirname public-key export-address --to=$datadirname/node1address
cd $tesseradirname
tessera -keygen -filename nodeKey
cp $rootdir/besu-tessera1.conf ./tessera.conf

cd $node2dir
cd $tesseradirname
tessera -keygen -filename nodeKey
cp $rootdir/besu-tessera2.conf ./tessera.conf

cd $rootdir/$basedirname
cp ../besu-genesis.json .
cp ../besu-genesis.py .
cp ../besu-getenode.py .
python3 besu-genesis.py

cd $node1dir
cd $tesseradirname
tessera -configfile tessera.conf &
cd ..

besu --data-path=$datadirname --genesis-file=../besu-genesis.json --network-id $networkid --rpc-http-enabled --rpc-http-api=ETH,NET,CLIQUE,EEA,PRIV --host-allowlist="*" --rpc-http-cors-origins="all" --p2p-port=$node1p2pport --rpc-http-port=$node1httpport  --privacy-enabled --privacy-url=http://127.0.0.1:9102 --privacy-public-key-file=Tessera/nodeKey.pub --min-gas-price=0 &

cd ..
sleep 30
curl -X POST --data '{"jsonrpc":"2.0","method":"net_enode","params":[],"id":1}' http://localhost:$node1httpport > enode.json
python3 besu-getenode.py
enodelink=$(cat enode.txt)

cd $node2dir
cd $tesseradirname
tessera -configfile tessera.conf &
cd ..
besu --data-path=$datadirname --genesis-file=../besu-genesis.json --network-id $networkid --bootnodes=$enodelink  --rpc-http-enabled --rpc-http-api=ETH,NET,CLIQUE,EEA,PRIV --host-allowlist="*" --rpc-http-cors-origins="all" --p2p-port=$node2p2pport --rpc-http-port=$node2httpport --privacy-enabled --privacy-url=http://127.0.0.1:9202 --privacy-public-key-file=Tessera/nodeKey.pub --min-gas-price=0 &

cd $node3dir
besu --data-path=$datadirname --genesis-file=../besu-genesis.json --network-id $networkid --bootnodes=$enodelink --rpc-http-enabled --rpc-http-api=ETH,NET,CLIQUE --host-allowlist="*" --rpc-http-cors-origins="all" --p2p-port=$node3p2pport --rpc-http-port=$node3httpport &

sudo add-apt-repository -y ppa:ethereum/ethereum
sudo apt-get update
sudo apt-get install ethereum -y

node1port=30306
node1rpcport=8551
node1httpport=3336
node2port=30307
node2rpcport=8552
node2httpport=3337
node3port=30308
node3rpcport=8553
node3httpport=3338

rm -rf ethereum
mkdir ethereum
cd ethereum
mkdir bnode
mkdir node1
mkdir node2
mkdir node3
echo '12345678' > password.txt
cp ../genesis.json .
cp ../createfiles.py .
geth --password password.txt --datadir node1/data account new > node1.txt
geth --password password.txt --datadir node2/data account new > node2.txt
geth --password password.txt --datadir node3/data account new > node3.txt
python3 createfiles.py
geth init --datadir node1/data genesis.json
geth init --datadir node2/data genesis.json
geth init --datadir node3/data genesis.json
bootnode -genkey bnode/boot.key
bootnode -nodekey bnode/boot.key -addr :30305 --writeaddress --verbosity 3 > enode.txt

enodehead=enode://
enodetail=@127.0.0.1:0?discport=30305
enodelink=$(cat enode.txt)
enodelink="$enodehead$enodelink$enodetail"
chainid=$(cat chainid.txt)
node1pubkey=$(cat node11.txt)
node2pubkey=$(cat node22.txt)
node3pubkey=$(cat node33.txt)

echo --------------------boot node command ---------------------
echo bootnode -nodekey bnode/boot.key -addr :30305 --verbosity 3

echo --------------------node1 command -------------------------
echo geth --datadir node1/data --port $node1port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.addr 54.80.244.149 --http.port $node1httpport --http.corsdomain '"*"' --http.vhosts '"*"' --http.api web3,eth,debug,personal,net --unlock $node1pubkey --password password.txt --authrpc.port $node1rpcport --miner.etherbase $node1pubkey --mine --syncmode '"full"' --vmdebug --verbosity 3 console

echo --------------------node2 command -------------------------
echo geth --datadir node2/data --port $node2port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.addr 54.80.244.149 --http.port $node2httpport --http.corsdomain '"*"' --http.vhosts '"*"' --http.api web3,eth,debug,personal,net --unlock $node2pubkey --password password.txt --authrpc.port $node2rpcport --miner.etherbase $node2pubkey --mine --syncmode '"full"' --vmdebug --verbosity 3 console

echo --------------------node3 command -------------------------
echo geth --datadir node3/data --port $node3port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.addr 54.80.244.149 --http.port $node3httpport --http.corsdomain '"*"' --http.vhosts '"*"' --unlock $node3pubkey --password password.txt --authrpc.port $node3rpcport --syncmode '"full"' --verbosity 3 console

echo ---------------node1 js command to check balance----------
echo eth.getBalance\(\"$node1pubkey\"\)

echo ---------------node2 js command to check balance----------
echo eth.getBalance\(\"$node2pubkey\"\)

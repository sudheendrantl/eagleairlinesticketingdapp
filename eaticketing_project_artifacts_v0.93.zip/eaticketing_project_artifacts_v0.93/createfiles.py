import json

try:

    # load existing json
    with open("genesis.json", 'r') as fhandle:
        genesis = json.loads(fhandle.read())

    # read 18 account files and retrieve the public keys
    nodekeys = []
    for i in range(18):
        f = open("account" + str(i) + ".txt")
        contents = f.read()
        f.close()
        nodekeys.append(contents[60:100])

    # path the extra data field with the only the first
    # account in each node
    header = genesis['extradata'][:66]
    #acc1 = genesis['extradata'][66:106]
    #acc2 = genesis['extradata'][106:146]
    #acc3 = genesis['extradata'][146:186]
    trailer = genesis['extradata'][146:len(genesis['extradata']) + 1]
    genesis['extradata'] = header+str(nodekeys[0])+str(nodekeys[6])+trailer

    # populate the 'alloc' json with all the 18 accounts
    keys = list(genesis['alloc'].keys())

    for i in range(18):
        if( i < len(keys)) :
            val = genesis['alloc'][keys[i]]
            del genesis['alloc'][keys[i]]
        else:
            val = str({"balance": "100000000000000000000"})
        genesis['alloc'][nodekeys[i]] = val

    # write the patched json
    with open("genesis.json", 'w') as fhandle:
        fhandle.write(json.dumps(genesis, indent=2))

    # get chainid details from json and write to chainid.txt file
    with open("chainid.txt", 'w') as fhandle:
        fhandle.write(str(genesis['config']['chainId']))

    # for all the 3 nodes, write the public key of the first
    # account into the specified files
    with open("node1acc1pubkey.txt", 'w') as fhandle:
        fhandle.write("0x"+str(nodekeys[0]))
    with open("node2acc1pubkey.txt", 'w') as fhandle:
        fhandle.write("0x"+str(nodekeys[6]))
    with open("node3acc1pubkey.txt", 'w') as fhandle:
        fhandle.write("0x"+str(nodekeys[12]))

except Exception as e:
    print("Exception occurred...", e)

Description of the files/artificacts of the eagle airlines ticketing DAPP
==========================================================================

1) commands.sh
--------------------------------------------------
The linux shell script used during the creation of geth accounts, initializing the network with a genesis.json (See "ea-step2-create-init-geth.bat" for details on how/when to use this commands.sh script).

2) contracts/eagleairlinesticket.sol
--------------------------------------------------
The main smart contract, central to the functionality of the eagle airlines tiketing DAPP.

3) createfiles.py
--------------------------------------------------
The python script used during the creation of geth accounts. This is a helper script that 
patches the template genesis.json with the actual values of public keys obtained during 
geth account creation.

4) eagleairlinesticket.json
--------------------------------------------------
The CloudFormation Template, defining all infrastructure for the eagle airlines 
ticketing DAPP, including:
  a) Resources for EC2, InternetGateway, Route, VPC, Subnet, Security Group, Key etc
  b) Resources for IAM Role for EC2
  c) Resources for S3 (used to transfer files b/w Desktop<====>S3<====>EC2)
  e) Parameters for allowing flexible user input for EC2 Instance Name, Key Name etc
  f) After EC2 Instance creation is done, the Admin role is attached through
     this template itself. Also, the installation of pip, geth and aws cli is done 
     as well, so that when the ubuntu ec2 is up, we can get started with application
     tasks, rather than worrying about infrastructure

5) eagleairlinesticket.pptx
--------------------------------------------------
Slide deck presentation describing the application and infrastructure design, the process 
and steps to be used for bringing up the infrastructure and application and some screenshots 
of the application output/tests.

6) eagleairlinesticket_project_hardhat_test_artifacts_v0.1.zip
--------------------------------------------------
Zip archive containing hardhat TEST .js code, a copy of contracts/eagleairlinesticket.sol.

7) genesis.json
--------------------------------------------------
The genesis.json template that will be used during the initialization of EVM (geth init). 

8) getaccountkeys.py
--------------------------------------------------
The python script used generate the public and private keys of the accounts created
across all nodes. This is required to connect Metamask and other wallet providers, which
require to import the private keys of the accounts.

9) README.txt
--------------------------------------------------
This README.TXT file

10) "release notes.txt"
-------------------------------------------------------
The release notes of the eagle airlines ticketing dapp artifacts.

11) solidityunittests/*.sol
--------------------------------------------------
Folder containing TEST smart contracts, used to perform automated unit testing of all 
functionality of the eagle airlines tiketing DAPP, using the solidity unit test plugin.

12) *.bat files
--------------------------------------------------
The windows batch files used during the creation of infrastructure, bringing up the nodes and
deleting the infrastructure. As the AWS CLI is being used, MAKE SURE TO INSTALL "AWS CLI" IN THE LOCAL MACHINE. (https://awscli.amazonaws.com/AWSCLIV2.msi). ONCE "AWS CLI" IS INSTALLED, OPEN
A "CMD.EXE" TERMINAL AND RUN "AWS Configure"; PROVIDE THE Key, Secret Key, Region TO BE USED. 
COPY THE ENTIRE PROJECT FOLDER INTO ANY LOCAL DIRECTORY AND THEN RUN THE FOLLOWING WINDOWS BATCH FILES IN THE SAME ORDER AS MENTIONED BELOW. FOLLOW THE INSTRUCTIONS AS PROMPTED BY THESE BATCH FILES
TO THE TEE.

ea-step1-create-stack.bat
ea-step2-create-init-geth.bat
ea-step3-run-nodes.bat
ea-step4-delete-stack.bat

-oOo-
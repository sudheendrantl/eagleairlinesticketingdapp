rootdir=$(pwd)
basedirname=ethereum
datadirname=data
bootnodename=bnode
node1name=node1
node2name=node2
node3name=node3
node1port=30306
node1rpcport=8551
node1httpport=3336

basedir=$rootdir/$basedirname
node1dir=$basedirname/$node1name
node2dir=$basedirname/$node2name
node3dir=$basedirname/$node3name
node1passwordlocation=password.txt
node2passwordlocation=password.txt
node3passwordlocation=password.txt
node2port=$((node1port+1))
node2rpcport=$((node1rpcport+1))
node2httpport=$((node1httpport+1))
node3port=$((node1port+2))
node3rpcport=$((node1rpcport+2))
node3httpport=$((node1httpport+2))

cd $rootdir
rm -rf $basedirname
mkdir $basedirname
mkdir $basedirname/$bootnodename
mkdir $basedirname/$node1name
mkdir $basedirname/$node2name
mkdir $basedirname/$node3name

cd $basedirname

echo '12345678' > password.txt

cp ../genesis.json .
cp ../createfiles.py .

geth --password $node1passwordlocation --datadir $node1dir/$datadirname account new > node1.txt
geth --password $node2passwordlocation --datadir $node2dir/$datadirname account new > node2.txt
geth --password $node3passwordlocation --datadir $node3dir/$datadirname account new > node3.txt

python3 createfiles.py

geth init --datadir $node1dir/$datadirname genesis.json
geth init --datadir $node2dir/$datadirname genesis.json
geth init --datadir $node3dir/$datadirname genesis.json

bootnode -genkey $bootnodename/boot.key
bootnode -nodekey $bootnodename/boot.key -addr :30305 --writeaddress --verbosity 3 > enode.txt

enodehead=enode://
enodetail=@127.0.0.1:0?discport=30305
enodelink=$(cat enode.txt)
enodelink="$enodehead$enodelink$enodetail"
chainid=$(cat chainid.txt)
node1pubkey=$(cat node11.txt)
node2pubkey=$(cat node22.txt)
node3pubkey=$(cat node33.txt)

echo --------------------boot node command ---------------------
echo bootnode -nodekey $bootnodename/boot.key -addr :30305 --verbosity 3

echo --------------------node1 command -------------------------
echo geth --datadir $node1dir/$datadirname --port $node1port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node1httpport --http.corsdomain \"*\" --http.vhosts \"*\" --unlock $node1pubkey --password password.txt --authrpc.port $node1rpcport --miner.etherbase $node1pubkey --mine --syncmode \"full\" --verbosity 3 console

echo --------------------node2 command -------------------------
echo geth --datadir $node2dir/$datadirname --port $node2port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node2httpport --http.corsdomain \"*\" --http.vhosts \"*\" --unlock $node2pubkey --password password.txt --authrpc.port $node2rpcport --miner.etherbase $node2pubkey --mine --syncmode \"full\" --verbosity 3 console

echo --------------------node3 command -------------------------
echo geth --datadir $node3dir/$datadirname --port $node3port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.port $node3httpport --http.corsdomain \"*\" --http.vhosts \"*\" --unlock $node3pubkey --password password.txt --authrpc.port $node3rpcport  --syncmode \"full\" --verbosity 3 console

echo ---------------node1 js command to check balance----------
echo eth.getBalance\(\"$node1pubkey\"\)

echo ---------------node2 js command to check balance----------
echo eth.getBalance\(\"$node2pubkey\"\)

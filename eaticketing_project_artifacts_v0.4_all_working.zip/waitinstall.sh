count=$(sudo cat /etc/environment |grep -c stage4) 
while (( $count < 1))
do
	echo "waiting for python, aws cli and geth installation to complete"
    sleep 5
    count=$(sudo cat /etc/environment |grep -c stage4)
done
echo "Python, geth and aws cli installation completed"
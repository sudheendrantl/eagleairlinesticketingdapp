rootdir=$(pwd)
basedirname=ethereum
datadirname=data
bootnodename=bnode
node1name=node1
node2name=node2
node3name=node3
node1port=30306
node1rpcport=8551
node1httpport=3336

basedir=$basedirname
node1dir=$node1name
node2dir=$node2name
node3dir=$node3name
node1passwordlocation=password.txt
node2passwordlocation=password.txt
node3passwordlocation=password.txt
node2port=$((node1port+1))
node2rpcport=$((node1rpcport+1))
node2httpport=$((node1httpport+1))
node3port=$((node1port+2))
node3rpcport=$((node1rpcport+2))
node3httpport=$((node1httpport+2))

cd $rootdir
rm -rf $basedirname
mkdir $basedirname
cd $basedirname

mkdir $bootnodename
mkdir $node1name
mkdir $node2name
mkdir $node3name

echo '12345678' > password.txt

cp ../genesis.json .
cp ../createfiles.py .

geth --password $node1passwordlocation --datadir $node1dir/$datadirname account new > node1.txt
geth --password $node1passwordlocation --datadir $node1dir/$datadirname account new > node12.txt
geth --password $node2passwordlocation --datadir $node2dir/$datadirname account new > node2.txt
geth --password $node2passwordlocation --datadir $node2dir/$datadirname account new > node22.txt
geth --password $node3passwordlocation --datadir $node3dir/$datadirname account new > node3.txt
geth --password $node3passwordlocation --datadir $node3dir/$datadirname account new > node32.txt

python3 createfiles.py

geth init --datadir $node1dir/$datadirname genesis.json
geth init --datadir $node2dir/$datadirname genesis.json
geth init --datadir $node3dir/$datadirname genesis.json

aws ec2 describe-instances --region us-east-1 --filters  "Name=instance-state-name, Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text > privateip.txt
privateip=$(cat privateip.txt)
privateip=127.0.0.1

bootnode -genkey $bootnodename/boot.key
bootnode -nodekey $bootnodename/boot.key -addr :30305 --writeaddress --verbosity 3 > enode.txt

enodehead=enode://
enodetail=@$privateip:0?discport=30305
enodelink=$(cat enode.txt)
enodelink="$enodehead$enodelink$enodetail"
chainid=$(cat chainid.txt)
node1acc1pubkey=$(cat node1_.txt)
node2acc1pubkey=$(cat node2_.txt)
node3acc1pubkey=$(cat node3_.txt)

echo writing boot node command to bnode.c
echo bootnode -nodekey $bootnodename/boot.key -addr $privateip:30305 --verbosity 3 > bnode.c

echo writing node1 command to node1.c
echo geth --datadir $node1dir/$datadirname --port $node1port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.corsdomain \"*\" --http.port $node1httpport --unlock $node1acc1pubkey --password password.txt --authrpc.port $node1rpcport --miner.etherbase $node1acc1pubkey --mine --syncmode \"full\" --verbosity 3  console > node1.c

echo writing node2 command to node2.c
echo geth --datadir $node2dir/$datadirname --port $node2port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.corsdomain \"*\" --http.port $node2httpport --unlock $node2acc1pubkey --password password.txt --authrpc.port $node2rpcport --miner.etherbase $node2acc1pubkey --mine --syncmode \"full\" --verbosity 3  console > node2.c

echo writing node3 command to node3.c
echo geth --datadir $node3dir/$datadirname --port $node3port --bootnodes $enodelink --networkid $chainid --ipcdisable --http --allow-insecure-unlock --http.corsdomain \"*\" --http.port $node3httpport --unlock $node3acc1pubkey --password password.txt --authrpc.port $node3rpcport  --syncmode \"full\" --verbosity 3 console > node3.c

aws s3 cp . s3://eaticketdapps3bucket --recursive --exclude "*" --include "*.c"

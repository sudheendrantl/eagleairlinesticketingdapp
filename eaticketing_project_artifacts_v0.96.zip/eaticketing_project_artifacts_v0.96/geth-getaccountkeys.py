import os
import sys

from web3.auto import w3
import binascii

try:

    dir_list = os.listdir()

    count = 1

    for i in range(len(dir_list)):
        substring = "UTC"
        string = dir_list[i]
        if ( 0 == string.find(substring) ):
            with open(dir_list[i]) as keyfile:
                encrypted_key = keyfile.read()
                private_key = w3.eth.account.decrypt(encrypted_key,'12345678')
                with open("privatekey"+str(count), "w") as privatekeyfile:
                    privatekeyfile.write(str(binascii.b2a_hex(private_key).decode()))
                with open("publickey"+str(count), "w") as publickeyfile:
                    publickeyfile.write(str(encrypted_key[12:53]))
                count += 1
                sys.stdout.write(str(count) + " keypairs written..." + "\r")
                sys.stdout.flush()

    print("geth-getaccountkeys completed successfully");

except Exception as e:
    print("Exception occurred in geth-getaccountkeys...", e)

Description of the files/artificacts of the eagle airlines ticketing DAPP
==========================================================================

--------------------------------------------------
1) besu-create-commands.sh
--------------------------------------------------
The linux shell script used during the creation of besu directories, initializing the network with  besu-genesis.json


--------------------------------------------------
2) besu-genesis.json
--------------------------------------------------
The genesis json template that will be used during the initialization of EVM (besu init). 


--------------------------------------------------
3) besu-genesis.py
--------------------------------------------------
The python script used during the creation of besu network. This is a helper script patches 
the besu-genesis.json file with the node1 address.


--------------------------------------------------
4) besu-getenode.py
--------------------------------------------------
The python script used before starting Node-2 and Node-3. This is a helper script gets the
enode link of Node-1 and saves it to a plain text file (enode.txt), making it easier for .sh
scripts to pick it up.


--------------------------------------------------
5) besu-start-node1.sh
--------------------------------------------------
The linux shell script used to start besu Node-1


--------------------------------------------------
6) besu-start-node2.sh
--------------------------------------------------
The linux shell script used to start besu Node-2


--------------------------------------------------
7) besu-start-node3.sh
--------------------------------------------------
The linux shell script used to start besu Node-3


--------------------------------------------------
8) contracts/eagleairlinesticket.sol
--------------------------------------------------
The main smart contract, central to the functionality of the eagle airlines tiketing DAPP.


--------------------------------------------------
9) ea-step*.bat
--------------------------------------------------

The windows batch files used during the creation of infrastructure, bringing up the nodes and
deleting the infrastructure. COPY THE ENTIRE PROJECT FOLDER INTO ANY LOCAL DIRECTORY AND THEN 
RUN THE FOLLOWING WINDOWS BATCH FILES IN THE SAME ORDER AS MENTIONED BELOW. 
FOLLOW THE INSTRUCTIONS AS PROMPTED BY THESE BATCH FILES.

ea-step1-create-aws-stack.bat
ea-step2-create-init-geth.bat
ea-step3-run-geth-nodes.bat
ea-step4-create-run-besu-nodes.bat
ea-step5-delete-aws-stack.bat


--------------------------------------------------
10) eagleairlinesticket.json
--------------------------------------------------
The Cloudformation template, defining all infrastructure for the eagle airlines 
ticketing DAPP, including:
  a) Resources for EC2, InternetGateway, Route, VPC, Subnet, Security Group, Key etc
  b) Resources for IAM Role for EC2
  c) Resources for S3 (used to transfer files b/w Desktop<====>S3<====>EC2)
  e) Parameters for allowing flexible user input for EC2 Instance Name, Key Name etc
  f) After EC2 Instance creation is done, the Admin role is attached through
     this template itself. Also, the installation of pip, geth and aws cli is done 
     as well, so that when the ubuntu ec2 is up, we can get started with application
     tasks, rather than worrying about infrastructure
  g) UserData definition, performing the installation of the following software
     automatically once the EC2 machine is up.
     - Python3
     - geth
     - AWS CLI
     - Besu and it's dependencies like JDK18 etc


--------------------------------------------------
11) eaglearilinesticket.pptx
--------------------------------------------------
Slide deck presentation describing the application and infrastructure design, the process 
and steps to be used for bringing up the infrastructure and application and some screenshots 
of the application output/tests.


--------------------------------------------------
12) geth-commands.sh
--------------------------------------------------
The linux shell script used during the creation of geth accounts, initializing the network with a genesis.json (See "ea-step2-create-init-geth.bat" for details on how/when to use this commands.sh script).


--------------------------------------------------
13) geth-createfiles.py
--------------------------------------------------
The python script used during the creation of geth accounts. This is a helper script that 
patches the template genesis.json with the actual values of public keys obtained during 
geth account creation.


--------------------------------------------------
14) geth-genesis.json
--------------------------------------------------
The genesis json template that will be used during the initialization of EVM (geth init). 


--------------------------------------------------
15) geth-getaccountkeys.py
--------------------------------------------------
The python script used generate the public and private keys of the accounts created
across all geth nodes. This is required to connect Metamask and other wallet providers, which
require to import the private keys of the accounts.


--------------------------------------------------
16) hardhat
--------------------------------------------------
The folder containing all hardhat related deliverables, mainly: hardhat/test/eagleairlinesticket.js which contains exhaustive code to test the main smart contract, a copy of the main smart contract is also kept under hardhat/contracts/eagleairlinesticket.sol. The hardhat/coverage/index.html file that has all the test coverage details.


--------------------------------------------------
17) PRE-REQUISITES.txt
--------------------------------------------------
This file describes all the pre-requisites to be installed, before attempting running
the *.bat files in this folder.


--------------------------------------------------
18) README.txt
--------------------------------------------------
This README.TXT file


--------------------------------------------------
19) RELEASE NOTES.txt
--------------------------------------------------
The release notes of the eagleairlinesticket DAPP, describing items including in each
release.


--------------------------------------------------
20) solidityunittests/*.sol
--------------------------------------------------
Folder containing TEST smart contracts, used to perform automated unit testing of all 
functionality of the eagle airlines tiketing DAPP, using the solidity unit test plugin.

-oOo-
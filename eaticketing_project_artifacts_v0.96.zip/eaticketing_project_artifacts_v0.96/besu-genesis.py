import json

try:

    # load existing json
    with open("besu-genesis.json", 'r') as fhandle:
        genesis = json.loads(fhandle.read())

    # load existing node1address file
    with open("Node-1/data/node1address", 'r') as fhandle:
        address = fhandle.read()

    # patch the extraData field with the address
    header = genesis['extraData'][:66]
    trailer = genesis['extraData'][106:len(genesis['extraData']) + 1]
    genesis['extraData'] = header+str(address[2:])+trailer

    # write the patched json
    with open("besu-genesis.json", 'w') as fhandle:
        fhandle.write(json.dumps(genesis, indent=2))
        
    print("besu-genesis.py completed successfully")

except Exception as e:
    print("Exception occurred...", e)

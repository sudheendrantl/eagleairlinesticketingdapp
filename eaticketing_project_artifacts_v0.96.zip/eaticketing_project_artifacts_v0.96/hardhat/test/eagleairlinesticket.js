const {
  time,
  loadFixture,
} = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");
const { expect } = require("chai");

const TWO_HOURS_IN_SECS 		= 1 * 2 * 60 * 60;
const THREE_HOURS_IN_SECS 		= 1 * 3 * 60 * 60;
const SIX_HOURS_IN_SECS 		= 1 * 6 * 60 * 60;
const TWENTY_HOURS_IN_SECS 		= 1 * 20 * 60 * 60;
const TWENTY_FIVE_HOURS_IN_SECS = 1 * 25 * 60 * 60;
const FIFTY_HOURS_IN_SECS 		= 1 * 50 * 60 * 60;
const HUNDRED_HOURS_IN_SECS 	= 1 * 100 * 60 * 60;

const MAX_FLIGHTS=5;
const MAX_TICKETS=5;

const FARE_ECONOMY = 500;
const FARE_BUSINESS = FARE_ECONOMY*2;
const FARE_FIRSTCLASS = FARE_ECONOMY*3;
const FARE_BUFFER = 5;

const REFUND_CANCEL_BEFORE_48HRS = 80;
const REFUND_CANCEL_BEFORE_24HRS = 60;
const REFUND_CANCEL_BEFORE_2HRS = 40;
const REFUND_WHEN_DELAYED_BY_2HRS = 20;
const REFUND_WHEN_DELAYED_BY_6HRS = 30;
const REFUND_WHEN_DELAYED_BY_MORE_THAN_6HRS = 40;

const SeatCategories = {ECONOMY:0, BUSINESS:1, FIRSTCLASS:2, INVALID:3};
const FlightStatuses = {SCHEDULED:0, STARTED:1, DELAYED_BY_2HRS:2,
						DELAYED_BY_6HRS:3, DELAYED_BY_MORE_THAN_6HRS:4, CANCELLED:5};
const TicketStatuses = {CONFIRMED:0, CANCELLED:1};

describe("eagleairlinesticket", function () {
  // We define a fixture to reuse the same setup in every test.
  // We use loadFixture to run this setup once, snapshot that state,
  // and reset Hardhat Network to that snapshot in every test.	
	async function deploy() {
		const eagleairlinesticket = await ethers.getContractFactory("eagleairlinesticket");
		const contract = await eagleairlinesticket.deploy();
		const [admin,opsuser1,opsuser2,user] = await ethers.getSigners();
		return {contract,admin,opsuser1,opsuser2,user};
	}
	
	describe("getAdminUser", function () {
		describe("Validations", function () {
			it(`Should pass when called by adminUser (TC-GAU-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getAdminUser()).not.to.be.reverted;
			});
			it(`Should pass when called by ops user (TC-GAU-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await contract.connect(opsuser1).getAdminUser()).not.to.be.reverted;
			});
			it(`Should fail when called by other users (TC-GAU-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getAdminUser()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});
	

    describe("getContractBalance", function(){
		describe("Validations", function () {
			it(`Should pass when called by adminUser (TC-GCB-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getAdminUser()).not.to.be.reverted;
			});
			it(`Should return zero balance initially (TC-GCB-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getContractBalance()).to.equal(0);
			});
			it(`Should pass when called by ops user (TC-GCB-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await contract.connect(opsuser1).getContractBalance()).not.to.be.reverted;
			});
			it(`Should fail when called by other users (TC-GCB-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getContractBalance()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});
	
    describe("getContractAddress", function(){
		describe("Validations", function () {
			it(`Should pass when called by adminUser (TC-GCA-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getContractAddress()).not.to.be.reverted;
			});
			it(`Should return the contracts address (TC-GCA-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getContractAddress()).to.equal(contract.target);
			});
			it(`Should pass when called by ops user (TC-GCA-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await contract.connect(opsuser1).getContractAddress()).not.to.be.reverted;
			});
			it(`Should fail when called by other users (TC-GCA-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getContractAddress()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});

    describe("getCurrentTimestamp", function(){
		describe("Validations", function () {
			it(`Should always pass (TC-GCT-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getCurrentTimestamp()).not.to.be.reverted;
			});
		});
	});

    describe("getOpsUsers", function(){
		describe("Validations", function () {
			it(`Should pass when called by adminUser (TC-GOU-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getOpsUsers()).not.to.be.reverted;
			});
			it(`Should return an array of length 0, as there are no operators added (TC-GOU-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				let result = await (contract.getOpsUsers());
				expect(Array.from(result).length).to.equal(0);
			});
			it(`Should return an array of length 1, after adding 1 operator, w/ right address of operator (TC-GOU-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.addOperator(opsuser1)).not.to.be.reverted;
				let result = await (contract.getOpsUsers());
				expect(Array.from(result).length).to.equal(1);
				expect(Array.from(result)[0]).to.equal(opsuser1.address);
			});
			it(`Should return count of 2, after adding 2 operators, w/ right addresses of operators (TC-GOU-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.addOperator(opsuser1)).not.to.be.reverted;
				expect(await contract.addOperator(opsuser2)).not.to.be.reverted;
				let result = await (contract.getOpsUsers());
				expect(Array.from(result).length).to.equal(2);
				expect(Array.from(result)[0]).to.equal(opsuser1.address);
				expect(Array.from(result)[1]).to.equal(opsuser2.address);
			});
			it(`Should fail when called by other users (TC-GOU-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getOpsUsers()).to.be.revertedWith("Not admin user");
			});
		});
	});

    describe("getOpsUsersCount", function(){
		describe("Validations", function () {
			it(`Should pass when called by adminUser (TC-GOUC-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getOpsUsersCount()).not.to.be.reverted;
			});
			it(`Should return 0, as there are no operators added (TC-GOUC-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.getOpsUsersCount()).to.equal(0);
			});
			it(`Should return 1, after adding 1 operator (TC-GOUC-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.addOperator(opsuser1)).not.to.be.reverted;
				expect(await contract.getOpsUsersCount()).to.equal(1);
			});
			it(`Should return 2, after adding 2 operators (TC-GOUC-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await contract.addOperator(opsuser1)).not.to.be.reverted;
				expect(await contract.addOperator(opsuser2)).not.to.be.reverted;
				expect(await contract.getOpsUsersCount()).to.equal(2);
			});
			it(`Should fail when called by other users (TC-GOUC-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getOpsUsersCount()).to.be.revertedWith("Not admin user");
			});
		});
	});

    describe("addOperator", function(){
		describe("Validations", function () {
			it(`Should pass when admin adds an operator (TC-AO-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
			});
			it(`Should pass when called by adminUser & right operator count to be returned (TC-AO-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.addOperator(opsuser2))).not.to.be.reverted;
				expect(await(contract.getOpsUsersCount())).to.equal(2);
			});
			it(`Should fail when non-admin users try to add operators (TC-AO-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).addOperator(opsuser1)).to.be.revertedWith("Not admin user");
			});
			it(`Should fail when trying to add a duplicate user (TC-AO-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				expect(await (contract.addOperator(opsuser1))).not.to.be.reverted;
				await expect(contract.addOperator(opsuser1)).to.be.revertedWith("Duplicate user");
			});
		});
	});

    describe("createSchedule", function(){
		describe("Validations", function () {
			it(`Should pass when opsuser adds a valid schedule (TC-CRS-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
			});
			it(`Should pass stress tests when adding ${MAX_FLIGHTS} flights (TC-CRS-2)`, async function () {	
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser2))).not.to.be.reverted;
				
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser2).createSchedule(i, flightTime)).not.to.be.reverted;
				}
			});
			it(`Should fail when non-ops users try to add a flight schedule (TC-CRS-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser2))).not.to.be.reverted;
				await expect(contract.connect(user).createSchedule(1000,flightTime)).to.be.revertedWith("Not ops user");
			});
			it(`Should fail when duplicate flight schedule is added by a valid ops user (TC-CRS-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000,flightTime)).to.be.revertedWith("Duplicate flight");
			});
		});
	});

    describe("cancelSchedule", function(){
		describe("Validations", function () {
			it(`Should pass when opsuser adds and then cancels a valid schedule (TC-CLS-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).cancelSchedule(1000))).not.to.be.reverted;
			});
			it(`Should pass stress tests when adding/cancelling ${MAX_FLIGHTS} flights (TC-CLS-2)`, async function () {	
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser2))).not.to.be.reverted;
				
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser2).createSchedule(i, flightTime)).not.to.be.reverted;
				}
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser2).cancelSchedule(i)).not.to.be.reverted;
				}
			});
			it(`Should fail when cancelling an already cancelled flight schedule (TC-CLS-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).cancelSchedule(1000))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).cancelSchedule(1000)).to.be.revertedWith("Cancelled flightId given");
			});
			it(`Should fail when cancelling an invalid flight schedule (TC-CLS-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).cancelSchedule(2000)).to.be.revertedWith("Invalid flight Id");
			});
			it(`should fail when cancelling a flight schedule is attempted by non ops users (TC-CLS-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(user).cancelSchedule(1000)).to.be.revertedWith("Not ops user");
			});
		});
	});

    describe("updateSchedule", function(){
		describe("Validations", function () {
			it(`Should pass when ops user adds & then updates schedule with SCHEDULED status (TC-UPS-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.SCHEDULED))).not.to.be.reverted;
			});
			it(`Should pass when ops user adds & then updates schedule with STARTED status (TC-UPS-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.STARTED))).not.to.be.reverted;
			});
			it(`Should pass when ops user adds & then updates schedule with DELAYED_BY_2HRS status (TC-UPS-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.DELAYED_BY_2HRS))).not.to.be.reverted;
			});
			it(`Should pass when ops user adds & then updates schedule with DELAYED_BY_6HRS status (TC-UPS-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.DELAYED_BY_6HRS))).not.to.be.reverted;
			});
			it(`Should pass when ops user adds & then updates schedule with DELAYED_BY_MORE_THAN_6HRS status (TC-UPS-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.DELAYED_BY_MORE_THAN_6HRS))).not.to.be.reverted;
			});
			it(`Should pass when ops user adds & then updates schedule with CANCELLED status (TC-UPS-6)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.CANCELLED))).not.to.be.reverted;
			});
			it(`Should pass stress test when adding/updating ${MAX_FLIGHTS} flight schedules (TC-UPS-7)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser1).createSchedule(i, flightTime)).not.to.be.reverted;
				}
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser1).updateSchedule(i,FlightStatuses.STARTED)).not.to.be.reverted;
				}
			});
			it(`Should fail when ops user adds and then updates schedule with INVALID status (TC-UPS-8)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).updateSchedule(1000,33)).to.be.revertedWith("Invalid flight status");
			});
			it(`Should fail when ops user attempts updating an already cancelled schedule (TC-UPS-9)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.CANCELLED))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).updateSchedule(1000,FlightStatuses.STARTED)).to.be.revertedWith("Cancelled flightId given");
			});
			it(`Should fail when ops user attempts updating the schedule for a invalid flight (TC-UPS-10)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).updateSchedule(2000,FlightStatuses.STARTED)).to.be.revertedWith("Invalid flight Id");
			});
			it(`Should fail when non-ops user attempts updating the schedule (TC-UPS-11)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				expect(await(contract.connect(opsuser1).createSchedule(1000,flightTime))).not.to.be.reverted;
				await expect(contract.connect(user).updateSchedule(1000,FlightStatuses.STARTED)).to.be.revertedWith("Not ops user");
			});
		});
	});

	function FlightStruct(flightId, flightTime, flightStatus) {
		this.flightId = flightId;
		this.flightTime = flightTime;
		this.flightStatus = flightStatus;
	}
	
    describe("getFlightSchedules", function(){
		describe("Validations", function () {
			it(`Should pass when operations have begun (TC-GFS-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).getFlightSchedules()).not.to.be.reverted;
			});
			it(`Should pass when 1 schedule added & count/flight id should match (TC-GFS-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				expect (Array.from(result).length).to.equal(1);
				let FlightArray = Array.from(result).map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				expect (FlightArray[0].flightId).to.equal(1000);
			});
			it(`Should pass when ${MAX_FLIGHTS} schedules added & counts/flight ids should match (TC-GFS-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect(contract.connect(opsuser1).createSchedule(i, flightTime)).not.to.be.reverted;
				}

				let result = await(contract.connect(user).getFlightSchedules());
				expect (Array.from(result).length).to.equal(MAX_FLIGHTS);
				let FlightArray = Array.from(result).map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});

				for (let i = 0; i < MAX_FLIGHTS; i++) {
					expect (FlightArray[i].flightId).to.equal(1000+i);
				}
			});
			it(`Should fail when operations have not begun (TC-GFS-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				expect(await(contract.addOperator(opsuser1))).not.to.be.reverted;
				await expect(contract.connect(user).getFlightSchedules()).to.be.revertedWith("Operations not started");
			});
		});
	});
	
    describe("getSeatCategories", function(){
		describe("Validations", function () {
			it(`Should pass when operations have begun (TC-GSC-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				expect(await contract.connect(user).getSeatCategories()).not.to.be.reverted;
			});
			it(`Should pass when operations have begun and right categories to be received (TC-GSC-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				expect(await(contract.connect(user).getSeatCategories())).to.equal("Economy|Business|Firstclass");
				expect(await(contract.connect(user).getTicketFares())).to.equal("Economy:500|Business:1000|Firstclass:1500");
			});
			it(`Should fail when operations have not begun (TC-GSC-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getSeatCategories()).to.be.revertedWith("Operations not started");
			});
		});
	});

    describe("getTicketFares", function(){
		describe("Validations", function () {
			it(`Should pass when operations have begun (TC-GTF-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				expect(await contract.connect(user).getTicketFares()).not.to.be.reverted;
			});
			it(`Should pass when operations have begun and right categories to be received (TC-GTF-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				expect(await(contract.connect(user).getTicketFares())).to.equal("Economy:500|Business:1000|Firstclass:1500");
			});
			it(`Should fail when operations have not begun (TC-GTF-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.connect(user).getTicketFares()).to.be.revertedWith("Operations not started");
			});
		});
	});


	describe("bookTicket", function() {
		describe("Validations", function () {
			it(`should pass when operations have begun, with valid flightId, seatCategory (TC-BKT-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
				let receipt = await result.wait(1);
				for (let item of receipt){
					let returnvalstring = JSON.stringify(item.args);
					expect(returnvalstring.includes("ticket booked")).to.equal(true);
				}
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} ECONOMY tickets (TC-BKT-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
					}
				}
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} BUSINESS class tickets (TC-BKT-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.BUSINESS,{value: FARE_BUSINESS+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
					}
				}
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} FIRSTCLASS tickets (TC-BKT-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.FIRSTCLASS,{value: FARE_FIRSTCLASS+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
					}
				}
			});
			it(`Should fail for invalid seat category (TC-BKT-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(1000,SeatCategories.INVALID)).to.be.revertedWith("Invalid seat category");				
			});
			it(`Should fail for invalid flight id (TC-BKT-6)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(5555,SeatCategories.ECONOMY)).to.be.revertedWith("Invalid flight Id");
			});
			it(`Should fail if booking attempted with insufficient funds for ECONOMY booking (TC-BKT-7)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value:FARE_ECONOMY})).to.be.revertedWith("Insufficient amount provided");
			});
			it(`Should fail if booking attempted with insufficient funds for ECONOMY booking (TC-BKT-8)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(1000,SeatCategories.BUSINESS,{value:FARE_BUSINESS})).to.be.revertedWith("Insufficient amount provided");
			});
			it(`Should fail if booking attempted with insufficient funds for FIRSTCLASS booking (TC-BKT-9)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(1000,SeatCategories.FIRSTCLASS,{value:FARE_FIRSTCLASS})).to.be.revertedWith("Insufficient amount provided");
			});
			it(`Should fail if booking attempted with ZERO funds for FIRSTCLASS booking (TC-BKT-10)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(1000,SeatCategories.FIRSTCLASS,{value:0})).to.be.revertedWith("Insufficient amount provided");
			});
			it(`Should fail if booking attempted for a cancelled flight (TC-BKT-11)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(2000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(3000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).cancelSchedule(2000)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(4000, flightTime)).not.to.be.reverted;
				await expect(contract.connect(user).bookTicket(2000,SeatCategories.ECONOMY)).to.be.revertedWith("Cancelled flightId given");
			});
		});
	});

	describe("cancelTicket", function() {
		describe("Validations", function () {
			it(`should pass when cancellation attempted for a flight scheduled after 100 hrs (TC-CLT-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
				let receipt = await result.wait(1);
				for (let item of receipt){
					let returnvalstring = JSON.stringify(item.args);
					expect(returnvalstring.includes("ticket booked")).to.equal(true);
					let index = returnvalstring.indexOf("ticket id:");
					let ticketId = parseInt(returnvalstring.substring(index+"ticket id:".length));
					await expect(contract.connect(user).cancelTicket(ticketId)).not.to.be.reverted;
				}
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} ECONOMY tickets (TC-CLT-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				let ticketsarray = [];
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
						let index = returnvalstring.indexOf("ticket id:");
						let ticketId = parseInt(returnvalstring.substring(index+"ticket id:".length));
						ticketsarray[i]=ticketId;
					}
				}

				for (let i = 0; i < MAX_TICKETS; i++) {
					await expect(contract.connect(user).cancelTicket(ticketsarray[i])).not.to.be.reverted;
				}
				
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} BUSINESS class tickets (TC-CLT-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				let ticketsarray = [];
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.BUSINESS,{value: FARE_BUSINESS+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
						let index = returnvalstring.indexOf("ticket id:");
						let ticketId = parseInt(returnvalstring.substring(index+"ticket id:".length));
						ticketsarray[i]=ticketId;
					}
				}

				for (let i = 0; i < MAX_TICKETS; i++) {
					await expect(contract.connect(user).cancelTicket(ticketsarray[i])).not.to.be.reverted;
				}
			});
			it(`should pass when stress test initiated for ${MAX_TICKETS} FIRSTCLASS tickets (TC-CLT-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(user).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				
				let ticketsarray = [];
				for (let i = 0; i < MAX_TICKETS; i++) {
					result = await (contract.connect(user).bookTicket(Flight[0].flightId,SeatCategories.FIRSTCLASS,{value: FARE_FIRSTCLASS+FARE_BUFFER}));
					let receipt = await result.wait(1);
					for (let item of receipt){
						let returnvalstring = JSON.stringify(item.args);
						expect(returnvalstring.includes("ticket booked")).to.equal(true);
						let index = returnvalstring.indexOf("ticket id:");
						let ticketId = parseInt(returnvalstring.substring(index+"ticket id:".length));
						ticketsarray[i]=ticketId;
					}
				}

				for (let i = 0; i < MAX_TICKETS; i++) {
					await expect(contract.connect(user).cancelTicket(ticketsarray[i])).not.to.be.reverted;
				}
			});
			it(`Should pass when user attempts to cancel ticket for flight delayed by 2 hours (TC-CLT-5)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) - TWENTY_FIVE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(opsuser1).updateSchedule(1000, FlightStatuses.DELAYED_BY_2HRS)).not.to.be.reverted;
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts to cancel ticket for flight delayed by 6 hours (TC-CLT-6)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) - TWENTY_FIVE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(opsuser1).updateSchedule(1000, FlightStatuses.DELAYED_BY_6HRS)).not.to.be.reverted;
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts to cancel ticket for flight delayed by >6 hours (TC-CLT-7)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) - TWENTY_FIVE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(opsuser1).updateSchedule(1000, FlightStatuses.DELAYED_BY_MORE_THAN_6HRS)).not.to.be.reverted;
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts cancelling ticket 3hrs before depature(TC-CLT-8)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + THREE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts cancelling ticket 20hrs before depature(TC-CLT-9)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + TWENTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts cancelling ticket 50hrs before depature(TC-CLT-10)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should pass when user attempts cancelling ticket 24-48hrs ahead of schedule (TC-CLT-11)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + TWENTY_FIVE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect (contract.connect(user).cancelTicket(0)).not.to.be.reverted;
			});
			it(`Should fail for invalid ticket Id (TC-CLT-12)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await (contract.connect(user).bookTicket(1000,SeatCategories.FIRSTCLASS,{value: FARE_FIRSTCLASS+FARE_BUFFER}));
				await expect(contract.connect(user).cancelTicket(555)).to.be.revertedWith("Booking not found");
			});
			it(`Should fail for already cancelled ticket (TC-CLT-13)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await (contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
				await expect(contract.connect(user).cancelTicket(0)).not.to.be.reverted;
				await expect(contract.connect(user).cancelTicket(0)).to.be.revertedWith("Ticket already cancelled");
			});
			it(`Should fail for user is attempting to cancel that does not belong to him/her (TC-CLT-14)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await (contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
				await expect(contract.cancelTicket(0)).to.be.revertedWith("Invalid ticket/user Id");
			});
			it(`Should fail when cancelling ticket on an ontime flight & status was updated by operator(TC-CLT-15)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) + HUNDRED_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(opsuser1).updateSchedule(1000, FlightStatuses.STARTED)).not.to.be.reverted;
				await expect(contract.connect(user).cancelTicket(0)).to.be.revertedWith("No refund. Ontime flight. Updated too.");
			});
			it(`Should fail when cancelling ticket on an ontime flight & status was updated by operator(TC-CLT-16)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest()) - FIFTY_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect(contract.connect(user).cancelTicket(0)).to.be.revertedWith("No refund. >48 hours after flight");
			});
			it(`Should fail when cancelling ticket b/w flightTime-2hrs - flightTime + 24hrs (TC-CLT-17)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime = (await time.latest());
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await contract.connect(user).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER});
				await expect (contract.connect(user).cancelTicket(0)).to.be.revertedWith("Cannot cancel now. Try 24 hours after flight time");
			});
		});
	});

	describe("initiateSettlementAndArchiveCompletedFlights", function() {
		describe("Validations", function () {
			it(`should pass when called by airline admin (TC-ISA-1)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.initiateSettlementAndArchiveCompletedFlights()).not.to.be.reverted;
			});
			it(`should pass various flightSchedules, FlightStatuses and ticketStatuses (TC-ISA-2)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				const flightTime1 = (await time.latest()) - FIFTY_HOURS_IN_SECS;
				const flightTime2 = (await time.latest()) - TWENTY_FIVE_HOURS_IN_SECS;
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				let ticketsarray = [];

				for (let i = 0; i < MAX_FLIGHTS; i++) {

					if( i%2 == 0 ){
						await expect(contract.connect(opsuser1).createSchedule(i, flightTime1)).not.to.be.reverted;
					}
					else{
						await expect(contract.connect(opsuser1).createSchedule(i, flightTime2)).not.to.be.reverted;
					}

					let result = await(contract.connect(user).getFlightSchedules());
					let Flight = result.map(function (element, index) {
						let [flightId, flightTime, flightStatus] = element;
						return new FlightStruct(flightId, flightTime, flightStatus);
					});
					ticketsarray[i]=[];
					
					for (let j = 0; j < MAX_TICKETS; j++) {
						let result = await (contract.connect(user).bookTicket(Flight[i].flightId,SeatCategories.FIRSTCLASS,{value: FARE_FIRSTCLASS+FARE_BUFFER}));
						let receipt = await result.wait(1);
						for (let item of receipt){
							let returnvalstring = JSON.stringify(item.args);
							expect(returnvalstring.includes("ticket booked")).to.equal(true);
							let index = returnvalstring.indexOf("ticket id:");
							let ticketId = parseInt(returnvalstring.substring(index+"ticket id:".length));
							ticketsarray[i][j]=ticketId;
						}
						if( j%2 == 1 && i%2 == 1 ){
							await expect (contract.connect(user).cancelTicket(ticketsarray[i][j])).not.to.be.reverted;
						}
					}

					if ( i%2 == 0 ){
						await expect (contract.connect(opsuser1).updateSchedule(Flight[i].flightId, FlightStatuses.CANCELLED)).not.to.be.reverted;
					}

					if( i == MAX_FLIGHTS/2 ){
						await expect(contract.initiateSettlementAndArchiveCompletedFlights()).not.to.be.reverted;
						expect(await contract.getContractBalance()).not.equal(0);
					}
				}
				let lastblocktime = await contract.getCurrentTimestamp();
				await time.increaseTo(lastblocktime+BigInt(FIFTY_HOURS_IN_SECS));
				await expect(contract.initiateSettlementAndArchiveCompletedFlights()).not.to.be.reverted;
				expect(await contract.getContractBalance()).to.equal(0);
			});
			it(`should fail when called by operators (TC-ISA-3)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(opsuser1).initiateSettlementAndArchiveCompletedFlights()).to.be.revertedWith("Not admin user");
			});
			it(`should fail when called by users (TC-ISA-4)`, async function () {
				const {contract,admin,opsuser1,opsuser2,user} = await loadFixture(deploy);
				await expect(contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect(contract.connect(user).initiateSettlementAndArchiveCompletedFlights()).to.be.revertedWith("Not admin user");
			});
		});
	});
});

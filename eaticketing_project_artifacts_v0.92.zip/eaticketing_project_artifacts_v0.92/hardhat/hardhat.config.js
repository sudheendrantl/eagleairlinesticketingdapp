require("@nomicfoundation/hardhat-toolbox");
require('hardhat-deploy-ethers')

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.20",
};

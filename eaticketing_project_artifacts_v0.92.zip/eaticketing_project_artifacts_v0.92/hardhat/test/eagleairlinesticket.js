const {
  time,
  loadFixture,
} = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");
const { expect } = require("chai");

const FIFTY_HOURS_IN_SECS = 1 * 50 * 60 * 60;
const TWENTY_FOUR_HOURS_IN_SECS = 1 * 24 * 60 * 60;
const FORTY_EIGHT_HOURS_IN_SECS = 1 * 48 * 60 * 60;
const TWO_HOURS_IN_SECS = 1 * 2 * 60 * 60;
const SIX_HOURS_IN_SECS = 1 * 6 * 60 * 60;

const MAX_FLIGHTS=10;
const MAX_TICKETS=10;

const FARE_ECONOMY = 500;
const FARE_BUSINESS = FARE_ECONOMY*2;
const FARE_FIRSTCLASS = FARE_ECONOMY*3;
const FARE_BUFFER = 5;

const REFUND_CANCEL_BEFORE_48HRS = 80;
const REFUND_CANCEL_BEFORE_24HRS = 60;
const REFUND_CANCEL_BEFORE_2HRS = 40;
const REFUND_WHEN_DELAYED_BY_2HRS = 20;
const REFUND_WHEN_DELAYED_BY_6HRS = 30;
const REFUND_WHEN_DELAYED_BY_MORE_THAN_6HRS = 40;

const SeatCategories = {ECONOMY:0, BUSINESS:1, FIRSTCLASS:2, INVALID:3};
const FlightStatuses = {SCHEDULED:0, STARTED:1, DELAYED_BY_2HRS:2,
						DELAYED_BY_6HRS:3, DELAYED_BY_MORE_THAN_6HRS:4, CANCELLED:5, ARCHIVED:6, INVALID:7};
const TicketStatuses = {CONFIRMED:0, CANCELLED:1};

describe("eagleairlinesticket", function () {
  // We define a fixture to reuse the same setup in every test.
  // We use loadFixture to run this setup once, snapshot that state,
  // and reset Hardhat Network to that snapshot in every test.	
	async function deploy() {
		const eagleairlinesticket = await ethers.getContractFactory("eagleairlinesticket");
		const contract = await eagleairlinesticket.deploy();
		const [owner, other, opsuser1, opsuser2] = await ethers.getSigners();
		return { contract, owner, other, opsuser1, opsuser2 };
	}
	
	describe("getAdminUser", function () {
		describe("Validations", function () {
			it(`getAdminUser should pass when called by adminUser`, async function () {
				const { contract, owner } = await loadFixture(deploy);
				await (contract.getAdminUser());
			});
			it(`getAdminUser should fail when called by other users`, async function () {
				const { contract, owner, other } = await loadFixture(deploy);
				await expect (contract.connect(other).getAdminUser()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});
	

    describe("getContractBalance", function(){
		describe("Validations", function () {
			it(`getContractBalance should pass when called by adminUser`, async function () {
				const { contract, owner } = await loadFixture(deploy);
				expect(await contract.getContractBalance()).to.equal(0);
			});
			it(`getContractBalance should fail when called by other users`, async function () {
				const { contract, owner, other } = await loadFixture(deploy);
				await expect (contract.connect(other).getContractBalance()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});

    describe("getContractAddress", function(){
		describe("Validations", function () {
			it(`getContractAddress should pass when called by adminUser`, async function () {
				const { contract, owner } = await loadFixture(deploy);
				expect(await contract.getContractAddress()).to.equal(contract.target);
			});
			it(`getContractAddress should fail when called by other users`, async function () {
				const { contract, owner, other } = await loadFixture(deploy);
				await expect (contract.connect(other).getContractAddress()).to.be.revertedWith("Not admin/ops user");
			});
		});
	});


    describe("getOpsUsers", function(){
		describe("Validations", function () {
			it(`getOpsUsers should pass when called by adminUser`, async function () {
				const { contract, owner } = await loadFixture(deploy);
				let result = await (contract.connect(owner).getOpsUsers());
				// initially there are no operators added and hence returned array length must be 0
				expect (Array.from(result).length).to.equal(0);
			});
			it(`getOpsUsers should fail when called by other users`, async function () {
				const { contract, owner, other } = await loadFixture(deploy);
				await expect (contract.connect(other).getOpsUsers()).to.be.revertedWith("Not admin user");
			});
		});
	});

    describe("getOpsUsersCount", function(){
		describe("Validations", function () {
			it(`getOpsUsersCount should pass when called by adminUser with right count`, async function () {
				const { contract, owner } = await loadFixture(deploy);
				// initially there are no operators added and hence returned operator count must be 0
				expect(await contract.getOpsUsersCount()).to.equal(0);
			});
			it(`getOpsUsersCount should fail when called by other users`, async function () {
				const { contract, owner, other } = await loadFixture(deploy);
				await expect (contract.connect(other).getOpsUsersCount()).to.be.revertedWith("Not admin user");
			});
		});
	});

    describe("addOperator", function(){
		describe("Validations", function () {
			it(`addOperator should pass when called by adminUser & getOpsUsersCount should return right count`, async function () {
				const { contract, owner, opsuser1 } = await loadFixture(deploy);
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				expect(await contract.getOpsUsersCount()).to.equal(1);
				await expect (contract.addOperator(opsuser1)).to.be.revertedWith("Duplicate user");
			});
			it(`addOperator should fail when called by other users`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				await expect (contract.connect(other).addOperator(opsuser2)).to.be.revertedWith("Not admin user");
			});
		});
	});

    describe("createSchedule", function(){
		describe("Validations", function () {
			it(`createSchedule should pass when called by ops w/o duplicate flight id & fail with duplicate flight id`, async function () {
				const { contract, owner, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect (contract.connect(opsuser1).createSchedule(i, flightTime)).not.to.be.reverted;
				}
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).to.be.revertedWith("Duplicate flight");
			});
			it(`createSchedule should fail when called by non ops users`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				//end users cannot create schedule
				await expect (contract.connect(other).createSchedule(1000,flightTime)).to.be.revertedWith("Not ops user");
				//admin user cannot create schedule
				await expect (contract.createSchedule(1000,flightTime)).to.be.revertedWith("Not ops user");
			});
		});
	});

    describe("cancelSchedule", function(){
		describe("Validations", function () {
			it(`cancelSchedule should pass when called by ops with valid flight id`, async function () {
				const { contract, owner, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect (contract.connect(opsuser1).createSchedule(i, flightTime)).not.to.be.reverted;
				}
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect (contract.connect(opsuser1).cancelSchedule(i)).not.to.be.reverted;
				}
			});
			it(`cancelSchedule should fail when called by non ops users`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000,flightTime)).not.to.be.reverted;
				await expect (contract.cancelSchedule(1000)).to.be.revertedWith("Not ops user");
			});
		});
	});

    describe("updateSchedule", function(){
		describe("Validations", function () {
			it(`updateSchedule should pass when called by ops with valid flight id with various flight statuses`, async function () {
				const { contract, owner, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					await expect (contract.connect(opsuser1).createSchedule(i, flightTime)).not.to.be.reverted;
				}
				for (let i = 1000; i < 1000+MAX_FLIGHTS; i++) {
					if ( i%2 == 0 ){
						if ( i%3 == 0 ){
							await expect (contract.connect(opsuser1).updateSchedule(i, FlightStatuses.STARTED)).not.to.be.reverted;
						}else{
							await expect (contract.connect(opsuser1).updateSchedule(i, FlightStatuses.DELAYED_BY_6HRS)).not.to.be.reverted;
						}
						await expect (contract.connect(opsuser1).updateSchedule(i, FlightStatuses.DELAYED_BY_6HRS)).not.to.be.reverted;
					}else{
						await expect (contract.connect(opsuser1).updateSchedule(i, FlightStatuses.CANCELLED)).not.to.be.reverted;
					}
				}
			});
			it(`updateSchedule should fail when called by non ops users, invalid flight id`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000,flightTime)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).updateSchedule(2000, FlightStatuses.STARTED)).to.be.revertedWith("Invalid flight Id");
				await expect (contract.updateSchedule(1000, FlightStatuses.STARTED)).to.be.revertedWith("Not ops user");
			});
		});
	});

	function FlightStruct(flightId, flightTime, flightStatus) {
		this.flightId = flightId;
		this.flightTime = flightTime;
		this.flightStatus = flightStatus;
	}
	
    describe("getFlightSchedules", function(){
		describe("Validations", function () {
			it(`getFlightSchedules should pass when operations have begun`, async function () {
				const { contract, owner, other, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(2000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(other).getFlightSchedules());
				expect (Array.from(result).length).to.equal(2);
				let FlightArray = Array.from(result).map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});
				expect (FlightArray[0].flightId).to.equal(1000);
				expect (FlightArray[1].flightId).to.equal(2000);
			});
			it(`getFlightSchedules should fail when operations have not begun`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(other).getFlightSchedules()).to.be.revertedWith("Operations not started");
			});
		});
	});
	
    describe("getSeatCategories", function(){
		describe("Validations", function () {
			it(`getSeatCategories should pass when operations have begun`, async function () {
				const { contract, owner, other, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await (contract.connect(other).getSeatCategories());
				expect (result).to.equal("Economy|Business|Firstclass");
			});
			it(`getSeatCategories should fail when operations have not begun`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(other).getSeatCategories()).to.be.revertedWith("Operations not started");
			});
		});
	});

    describe("getTicketFares", function(){
		describe("Validations", function () {
			it(`getTicketFares should pass when operations have begun`, async function () {
				const { contract, owner, other, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await (contract.connect(other).getTicketFares());
				expect (result).to.equal("Economy:500|Business:1000|Firstclass:1500");
			});
			it(`getTicketFares should fail when operations have not begun`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(other).getTicketFares()).to.be.revertedWith("Operations not started");
			});
		});
	});

	describe("bookTicket", function() {
		describe("Validations", function () {
			it(`bookTicket should pass when operations have begun, with valid flightId, seatCategory`, async function () {
				const { contract, owner, other, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				let result = await(contract.connect(other).getFlightSchedules());
				let Flight = result.map(function (element, index) {
					let [flightId, flightTime, flightStatus] = element;
					return new FlightStruct(flightId, flightTime, flightStatus);
				});

				for (let i = 0; i < MAX_TICKETS; i++) {
					let result = await (contract.connect(other).bookTicket(Flight[0].flightId,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER}));
				}
			});
			it(`bookTicket should fail when operations have not begun`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(other).bookTicket(1000,SeatCategories.ECONOMY)).to.be.revertedWith("Operations not started");
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect (contract.connect(other).bookTicket(2000,SeatCategories.ECONOMY)).to.be.revertedWith("Invalid flight Id");
				await expect (contract.connect(other).bookTicket(1000,SeatCategories.INVALID)).to.be.revertedWith("Invalid seat category");
			});
		});
	});

	describe("cancelTicket", function() {
		describe("Validations", function () {
			it(`cancelTicket should pass when operations have begun, with valid ticketid`, async function () {
				const { contract, owner, other, opsuser1 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect (contract.connect(other).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER})).not.to.be.reverted;
				await expect (contract.connect(other).cancelTicket(0)).not.to.be.reverted;
			});
			it(`cancelTicket should fail when operations have not begun, for invalid ticketid`, async function () {
				const { contract, owner, other, opsuser1, opsuser2 } = await loadFixture(deploy);
				const flightTime = (await time.latest()) + FIFTY_HOURS_IN_SECS;
				await expect (contract.addOperator(opsuser1)).not.to.be.reverted;
				await expect (contract.connect(other).cancelTicket(0)).to.be.revertedWith("Operations not started");
				await expect (contract.connect(opsuser1).createSchedule(1000, flightTime)).not.to.be.reverted;
				await expect (contract.connect(other).bookTicket(1000,SeatCategories.ECONOMY,{value: FARE_ECONOMY+FARE_BUFFER})).not.to.be.reverted;
				await expect (contract.connect(other).cancelTicket(1)).to.be.revertedWith("Booking not found");
				await expect (contract.connect(owner).cancelTicket(0)).to.be.revertedWith("Invalid ticket/user Id");
			});
		});
	});

});

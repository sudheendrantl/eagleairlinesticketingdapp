basedirname=besu
datadirname=data
node1name=Node-1
node2name=Node-2
node3name=Node-3
node1dir=$basedirname/$node1name
node2dir=$basedirname/$node2name
node3dir=$basedirname/$node3name
node1datadir=$node1dir/$datadirname
node2datadir=$node2dir/$datadirname
node3datadir=$node3dir/$datadirname

node1p2pport=30309
node1httpport=8548
node2p2pport=$((node1p2pport+1))
node2httpport=$((node1httpport+1))
node3p2pport=$((node1p2pport+2))
node3httpport=$((node1httpport+2))

networkid=1338

PATH=$PATH:/besu-23.10.3/bin

curl -X POST --data '{"jsonrpc":"2.0","method":"net_enode","params":[],"id":1}' http://localhost:$node1httpport > enode.json
python3 besu-getenode.py
enodelink=$(cat enode.txt)

cd $node3dir
besu --data-path=$datadirname --genesis-file=../besu-genesis.json --network-id $networkid --bootnodes=$enodelink --rpc-http-enabled --rpc-http-api=ETH,NET,CLIQUE --host-allowlist="*" --rpc-http-cors-origins="all" --p2p-port=$node3p2pport --rpc-http-port=$node3httpport
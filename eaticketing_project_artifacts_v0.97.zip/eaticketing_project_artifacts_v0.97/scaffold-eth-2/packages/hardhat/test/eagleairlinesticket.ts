import { expect } from "chai";
import { ethers } from "hardhat";
import { eagleairlinesticket } from "../typechain-types";

describe("eagleairlinesticket", function () {
  // We define a fixture to reuse the same setup in every test.

  let contract: eagleairlinesticket;
  before(async () => {
    const [owner] = await ethers.getSigners();
    const yourContractFactory = await ethers.getContractFactory("eagleairlinesticket", {signer: owner});
    contract = (await yourContractFactory.deploy(owner.address)) as eagleairlinesticket;
    await contract.deployed();
  });

  describe("Deployment", function () {
  });
});

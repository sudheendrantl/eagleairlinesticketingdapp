import json

try:

    # load existing json
    with open("enode.json", 'r') as fhandle:
        enodejson = json.loads(fhandle.read())

    # write the patched json
    with open("enode.txt", 'w') as fhandle:
        fhandle.write(enodejson['result'])

except Exception as e:
    print("Exception occurred...", e)
